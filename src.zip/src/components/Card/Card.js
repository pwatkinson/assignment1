import React from 'react';
import PropTypes from 'prop-types';

import styles from './Card.module.css';
/*
    CSS modules allow you to reuse class names in different components
    class names are generated after you build the react app
    reduces likelihood of classes clashing
    If you target tags, you won't get the benefits of CSS modules
*/

const Card = (props) => {
    // object destructuring
    const { title, text } = props;
     
    return (
        <div className={`${styles.card}`}>
            <h3 className={`${styles.title}`}>{title}</h3>
            <p className={`${styles.text}`}>{text}</p>
        </div>        
    );
};

Card.propTypes = {
    title: PropTypes.string,
    text: PropTypes.string
}

export default Card;